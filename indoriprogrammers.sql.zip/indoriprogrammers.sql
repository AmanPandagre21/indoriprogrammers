-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 14, 2021 at 07:28 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `indoriprogrammers`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminsdetail`
--

CREATE TABLE `adminsdetail` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminsdetail`
--

INSERT INTO `adminsdetail` (`id`, `username`, `password`, `date`) VALUES
(1, 'indoriprogrammers', '$2y$10$E7e887LJBd9MVi.8jl7OJuROBTLjrTw/awzP0suxL7VxeR729P6am', '24-12-2020\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `contactdetail`
--

CREATE TABLE `contactdetail` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` bigint(255) NOT NULL,
  `message` mediumtext NOT NULL,
  `status` int(255) NOT NULL DEFAULT 0,
  `dateandtime` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contactdetail`
--

INSERT INTO `contactdetail` (`id`, `name`, `email`, `phone`, `message`, `status`, `dateandtime`) VALUES
(1, 'aman', 'aman@gmail.com', 7787878855, 'rerererere', 0, '2007-05-21 17:13:57.000000'),
(2, 'aman', 'aman@gmail.com', 7787878822, 'cfcvwvc', 1, '2011-05-21 13:17:56.000000');

-- --------------------------------------------------------

--
-- Table structure for table `programmersdetail`
--

CREATE TABLE `programmersdetail` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `image` mediumtext NOT NULL,
  `projects_link` varchar(255) NOT NULL,
  `skills` varchar(1000) NOT NULL,
  `profile` varchar(1000) NOT NULL,
  `tm_and_cd` int(11) NOT NULL DEFAULT 0,
  `status` int(255) NOT NULL DEFAULT 1,
  `dateandtime` varchar(255) NOT NULL,
  `updated_at` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programmersdetail`
--

INSERT INTO `programmersdetail` (`id`, `name`, `phone`, `email`, `image`, `projects_link`, `skills`, `profile`, `tm_and_cd`, `status`, `dateandtime`, `updated_at`) VALUES
(9, 'Jhon', '898989898989', 'jhon@gmail.com', '2db01dabeecc4259e1c46a8eaeb46af0.jpg', 'www.google.com', 'Java, C, C++, perl, ruby', '4', 1, 1, '21-07-21 21:18:17', ''),
(10, 'Dwane', '898989898989', 'dwane@gmail.com', 'c8c61a379f9c9164b16e5ccfe6a565dd.jpg', 'www.google.com', 'Java, C, C++, perl, ruby', '1', 1, 1, '09-08-21 12:58:15', '');

-- --------------------------------------------------------

--
-- Table structure for table `programmersrequests`
--

CREATE TABLE `programmersrequests` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `skill` varchar(255) NOT NULL,
  `tm_and_cd` varchar(255) NOT NULL,
  `status` int(255) NOT NULL DEFAULT 0,
  `dateandtime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programmersrequests`
--

INSERT INTO `programmersrequests` (`id`, `name`, `email`, `phone`, `skill`, `tm_and_cd`, `status`, `dateandtime`) VALUES
(1, 'Divyanshu', 'divyanshu@gmail.com', '7049223343', 'flutter', 'yes', 1, '16-03-21 11:38:02'),
(2, 'najkk', 'amcan@gmail.com', '868688989999', 'hrloofowjfwfiw', 'yes', 1, '04-05-21 12:25:22'),
(3, 'aman', 'apandagreji.2002@gmail.com', '898989898989', 'hrloofowjfwfiw', 'yes', 1, '11-05-21 13:18:35'),
(4, 'aman', 'aman@gmail.com', '898989898989', 'hrloo', 'yes', 0, '16-05-21 18:28:10'),
(5, 'aman', 'amanss@gmail.com', '898989898989', 'hrloo', 'yes', 1, '16-05-21 18:28:19');

-- --------------------------------------------------------

--
-- Table structure for table `programmers_profiles`
--

CREATE TABLE `programmers_profiles` (
  `id` int(255) NOT NULL,
  `programmer_profile` varchar(1000) NOT NULL,
  `status` int(13) NOT NULL DEFAULT 1,
  `dateandtime` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `programmers_profiles`
--

INSERT INTO `programmers_profiles` (`id`, `programmer_profile`, `status`, `dateandtime`) VALUES
(1, 'App Developer', 1, '13-03-21 14:34:11'),
(4, 'Wordpress Developer', 1, '13-03-21 14:36:43'),
(5, 'Frontend Developer', 1, '13-03-21 17:41:01'),
(6, 'Graphic Designer', 1, '16-03-21 11:46:30'),
(7, 'data science', 1, '04-05-21 12:24:44'),
(9, 'java developer', 1, '07-05-21 17:02:53'),
(10, 'cn', 1, '21-05-21 20:35:50'),
(11, 'python developer', 1, '23-05-21 08:39:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminsdetail`
--
ALTER TABLE `adminsdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactdetail`
--
ALTER TABLE `contactdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programmersdetail`
--
ALTER TABLE `programmersdetail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programmersrequests`
--
ALTER TABLE `programmersrequests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programmers_profiles`
--
ALTER TABLE `programmers_profiles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminsdetail`
--
ALTER TABLE `adminsdetail`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contactdetail`
--
ALTER TABLE `contactdetail`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `programmersdetail`
--
ALTER TABLE `programmersdetail`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `programmersrequests`
--
ALTER TABLE `programmersrequests`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `programmers_profiles`
--
ALTER TABLE `programmers_profiles`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
